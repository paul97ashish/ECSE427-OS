#include <stdio.h>

//Structs 

struct PCB {
	FILE *PC;
	int ramInd;
	
};


struct PCB *makePCB(FILE *p);
//functions
