// public functions

int interpreter(char buf0[], char buf1[], char buf2[], char buf3[]);
