void addToRAM(FILE *p);
FILE *ram[10];
int numOfProgs;
//function


