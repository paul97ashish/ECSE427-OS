// public functions

// returns TRUE (1) if parsed successfully, otherwise FALSE (0)
int parse(char buffer[], char arg0[], char arg1[], char arg2[], char arg3[]);
int prompt(char buffer[]);

