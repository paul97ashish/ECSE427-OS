char *getVal(char *var);
void insert(char *variable, char *value);